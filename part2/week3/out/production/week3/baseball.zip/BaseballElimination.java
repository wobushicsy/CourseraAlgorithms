import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.FordFulkerson;
import edu.princeton.cs.algs4.FlowNetwork;

import java.util.HashMap;
import java.util.HashSet;

public class BaseballElimination {

    private final int numberOfTeams;
    private final HashMap<String, Integer> teams;
    private HashMap<String, TeamInfo> data;

    // create a baseball division from given filename in format specified below
    public BaseballElimination(String filename) {
        In in = new In(filename);
        numberOfTeams = in.readInt();
        teams = new HashMap<>();
        data = new HashMap<>();
        for (int i = 0; i < numberOfTeams; i += 1) {
            String name = in.readString();
            int wins = in.readInt();
            int losses = in.readInt();
            int remaining = in.readInt();
            int[] against = new int[numberOfTeams];
            for (int j = 0; j < numberOfTeams; j += 1) {
                int numberOfRemainingGames = in.readInt();
                against[i] = numberOfRemainingGames;
            }

            teams.put(name, i);
            TeamInfo info = new TeamInfo(wins, losses, remaining, against);
            data.put(name, info);
        }
    }

    // number of teams
    public int numberOfTeams() {
        return numberOfTeams;
    }

    // all teams
    public Iterable<String> teams() {
        return teams.keySet();
    }

    // number of wins for given team
    public int wins(String team) {
        TeamInfo info = data.get(team);
        return info.getWins();
    }

    // number of losses for given team
    public int losses(String team) {
        TeamInfo info = data.get(team);
        return info.getLosses();
    }

    // number of remaining games for given team
    public int remaining(String team) {
        TeamInfo info = data.get(team);
        return info.getRemaining();
    }

    // number of remaining games between team1 and team2
    public int against(String team1, String team2) {
        TeamInfo info = data.get(team1);
        int index = teams.get(team2);
        return info.getAgainst()[index];
    }

    // is given team eliminated?
    public boolean isEliminated(String team) {
        return false;
    }

    // subset R of teams that eliminates given team; null if not eliminated
    public Iterable<String> certificateOfElimination(String team) {
        return null;
    }

    public static void main(String[] args) {
        BaseballElimination division = new BaseballElimination(args[0]);
        for (String team : division.teams()) {
            if (division.isEliminated(team)) {
                StdOut.print(team + " is eliminated by the subset R = { ");
                for (String t : division.certificateOfElimination(team)) {
                    StdOut.print(t + " ");
                }
                StdOut.println("}");
            }
            else {
                StdOut.println(team + " is not eliminated");
            }
        }
    }
}
