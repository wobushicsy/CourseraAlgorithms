public class TeamInfo {

    private final int wins;
    private final int losses;
    private final int remaining;
    private final int[] against;

    public TeamInfo(int wins, int losses, int remaining, int[] against) {
        this.wins = wins;
        this.losses = losses;
        this.remaining = remaining;
        this.against = against;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public int getRemaining() {
        return remaining;
    }

    public int[] getAgainst() {
        return against;
    }
}
