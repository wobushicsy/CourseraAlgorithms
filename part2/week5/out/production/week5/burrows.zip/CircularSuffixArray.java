import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;
import java.util.HashMap;

public class CircularSuffixArray {

    private final int length;
    private final int[] index;

    // circular suffix array of s
    public CircularSuffixArray(String s) {
        // corner case check
        if (s == null) {
            throw new IllegalArgumentException("Illegal command line argument");
        }

        // initialize variables
        length = s.length();
        index = new int[length];
        HashMap<String, Integer> ref = new HashMap<>();
        String[] strings = new String[length];

        // generate circular suffix array
        strings[0] = s;
        StringBuilder stringBuilder = new StringBuilder(s);
        ref.put(s, 0);
        for (int i = 1; i < length; i += 1) {
            char first = stringBuilder.charAt(0);
            stringBuilder.insert(length, first);
            stringBuilder.deleteCharAt(0);
            String tmp = stringBuilder.toString();
            ref.put(tmp, i);
            strings[i] = stringBuilder.toString();
        }

        Arrays.sort(strings);

        for (int i = 0; i < strings.length; i += 1) {
            String cur = strings[i];
            int srcIndex = ref.get(cur);
            index[i] = srcIndex;
        }

    }

    // length of s
    public int length() {
        return length;
    }

    // returns index of ith sorted suffix
    public int index(int i) {
        if (i < 0 || i >= length) {
            throw new IllegalArgumentException("Index is out of bound");
        }
        return index[i];
    }

    // unit testing (required)
    public static void main(String[] args) {
        String s = "";
        CircularSuffixArray circularSuffixArray = new CircularSuffixArray(s);
        for (int i = 0; i < circularSuffixArray.length(); i += 1) {
            StdOut.println(circularSuffixArray.index(i));
        }
    }

}
