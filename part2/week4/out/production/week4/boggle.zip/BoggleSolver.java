import java.util.HashSet;
import java.util.LinkedList;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.TST;

public class BoggleSolver {

    private final LinkedList<String> dictionary;
    private final TST<Integer> prefixTrie;

    // Initializes the data structure using the given array of strings as the dictionary.
    // (You can assume each word in the dictionary contains only the uppercase letters A through Z.)
    public BoggleSolver(String[] dictionary) {
        this.dictionary = new LinkedList<>();
        prefixTrie = new TST<>();
        for (String word : dictionary) {
            this.dictionary.add(word);
            prefixTrie.put(word, score(word));
        }
    }

    private int score(String word) {
        int length = word.length();
        int score = 0;
        switch (length) {
            case 0: case 1: case 2:
                break;
            case 3: case 4:
                score = 1;
                break;
            case 5:
                score = 2;
                break;
            case 6:
                score = 3;
                break;
            case 7:
                score = 5;
                break;
            default:
                score = 11;
        }

        return score;
    }

    private int hash(int i, int j, int rows) {
        return i * rows + j;
    }

    private Iterable<Integer> neighbor(int row, int col, int rows, int cols) {
        LinkedList<Integer> neighbor = new LinkedList<>();
        for (int i = -1; i <= 1; i += 1) {
            for (int j = -1; j <= 1; j += 1) {
                if (i == 0 && j == 0) {
                    continue;
                }
                int indexI = row + i;
                int indexJ = col + j;
                if (indexI < 0 || indexI >= rows || indexJ < 0 || indexJ >= cols) {
                    continue;
                }
                neighbor.add(hash(indexI, indexJ, rows));
            }
        }

        return neighbor;
    }

    private void dfs(int srcI, int srcJ, BoggleBoard board, HashSet<String> validWords,
                     boolean[] searched, String s) {
        if (dictionary.contains(s) && s.length() >= 3) {
            validWords.add(s);
        }
        boolean hasPrefix = false;
        for (String withPrefix : prefixTrie.keysWithPrefix(s)) {
            hasPrefix = true;
            break;
        }
        if (!hasPrefix) {
            return;
        }
        int rows = board.rows();
        int cols = board.cols();
        int hash = hash(srcI, srcJ, rows);
        boolean[] newSearched = new boolean[searched.length];
        System.arraycopy(searched, 0, newSearched, 0, searched.length);
        newSearched[hash] = true;
        for (int neighbor : neighbor(srcI, srcJ, rows, cols)) {
            if (searched[neighbor]) {
                continue;
            }
            int i = neighbor / rows;
            int j = neighbor % rows;
            if (i == srcI && j == srcJ) {
                continue;
            }
            char c = board.getLetter(i, j);
            String s1;
            if (c == 'Q') {
                s1 = "QU";
            } else {
                s1 = "" + c;
            }
            dfs(i, j, board, validWords, newSearched, s + s1);
        }
    }

    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board) {
return null;
    }

    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word) {
return 0;
    }

    public static void main(String[] args) {
//        args = new String[2];
//        args[0] = "dictionary-algs4.txt";
//        args[1] = "board-q.txt";
        In in = new In(args[0]);
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(args[1]);
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
    }
}
